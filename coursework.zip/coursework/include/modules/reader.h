#include <stdio.h>
#include <stdlib.h>
#include <string.h>


product_t* parse_products_from_file(char* file_name, unsigned int* product_count);