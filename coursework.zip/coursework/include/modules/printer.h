#include "global.h"
#include "product.h"

#include <stdio.h>


void print_stock_report(product_t* products, unsigned int product_count);
void print_product(product_t product);